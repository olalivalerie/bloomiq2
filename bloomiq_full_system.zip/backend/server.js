const express=require('express');const cors=require('cors');const path=require('path');require('dotenv').config();
const ai=require('./routes/ai');const sensors=require('./routes/sensors');const control=require('./routes/control');
require('./services/mqtt');require('./services/automation');
const app=express();app.use(cors());app.use(express.json());app.use(express.static(path.join(__dirname,'public')));
app.use('/api/ai',ai);app.use('/api/sensors',sensors);app.use('/api/control',control);
app.listen(process.env.PORT||3000,()=>console.log('BloomIQ Full System running'));