const axios=require('axios');const T=process.env.THINGSBOARD_URL;const token=process.env.DEVICE_TOKEN;
module.exports={async getTelemetry(){return (await axios.get(`${T}/api/v1/${token}/telemetry`)).data;},
async sendCommand(cmd){await axios.post(`${T}/api/v1/${token}/attributes`,{command:cmd});}};