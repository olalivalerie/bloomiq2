const axios=require('axios');module.exports={async reply(m){
const r=await axios.post('https://api.openai.com/v1/chat/completions',{model:'gpt-4.1',messages:[{role:'system',content:'BloomIQ assistant'},{role:'user',content:m}]},{headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`}});
return r.data.choices[0].message.content;}};