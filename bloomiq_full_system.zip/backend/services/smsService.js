const tw=require('twilio')(process.env.TWILIO_SID,process.env.TWILIO_TOKEN);
module.exports={send(m){return tw.messages.create({body:m,from:process.env.TWILIO_NUMBER,to:process.env.ADMIN_PHONE});}};