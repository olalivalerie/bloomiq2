const r=require('express').Router();const ai=require('../services/aiService');
r.post('/',async(req,res)=>res.json({reply:await(ai.reply(req.body.message))}));module.exports=r;