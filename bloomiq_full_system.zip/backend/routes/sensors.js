const r=require('express').Router();const tb=require('../services/thingsboard');
r.get('/',async(req,res)=>res.json(await tb.getTelemetry()));module.exports=r;