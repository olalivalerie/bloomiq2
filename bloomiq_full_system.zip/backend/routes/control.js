const r=require('express').Router();const tb=require('../services/thingsboard');
r.post('/water',async(req,res)=>{await tb.sendCommand(req.body.cmd);res.json({ok:true});});module.exports=r;